# THINK2TECH — Learn Beyond Limits

Independent full-stack starter implementation based on the supplied product specification.
It is **not** an extraction of the original Base44 source code.

## Stack
- React + TypeScript + Vite
- Tailwind CSS
- Node.js + Express
- PostgreSQL + Prisma
- Optional server-side Google Gemma API integration

## Included now
- Responsive navy/aqua application shell and persistent sidebar on desktop
- Dashboard with demo learning metrics
- Nine-subject explorer and searchable seeded concept catalogue
- Concept detail view and bookmark action
- Subject-wise concept relationship explorer (separate graph data per subject)
- Flashcards with flip / known / revision controls (demo state in browser)
- Smart Quiz setup, sample fallback quiz, scoring and review
- Visual Lab sorting stepper
- Tech Tool Guide and task-based recommendations
- AI assistant endpoint with explicit demo fallback
- Gemma status menu and status endpoint (never returns the API key)
- Notes upload endpoint with file validation; actual OCR/document AI pipeline is not yet wired
- Prisma schema for users, concepts, bookmarks, notes, flashcards, quizzes and progress

## Requirements
- Node.js 20+
- Docker Desktop (or a PostgreSQL 16 database)
- npm

## Run locally
1. Copy `.env.example` to `.env` in the project root.
2. Start PostgreSQL: `docker compose up -d`.
3. Install dependencies: `npm install`.
4. Generate Prisma client: `npm run db:generate`.
5. Create tables: `npm run db:migrate -w server -- --name init`.
6. Seed starter concepts: `npm run db:seed`.
7. Start both apps: `npm run dev`.
8. Frontend: http://localhost:5173 — API: http://localhost:4000/api/health

## Gemma
Set `GOOGLE_AI_API_KEY` in the root `.env` file. The server calls Google's Generative Language API using the configured `GEMMA_MODEL`. Test with the AI Assistant after starting the server. The UI status is based on server configuration; the endpoint's `tested` field remains false until a successful live request has occurred during the running process. No key is sent to the browser.

If no key is configured, the AI endpoint returns an explicitly labelled demo fallback. Do not describe fallback output as a real Gemma response.

## Database
The Prisma schema is in `server/prisma/schema.prisma`. Seed content is deliberately starter content, not a complete textbook. Extend `server/prisma/seed.ts` with reviewed material for additional chapters and concepts.

## Deployment
### DigitalOcean
- Deploy the Node server as an App Platform service and build the React client with `npm run build -w client`.
- Provision managed PostgreSQL and set `DATABASE_URL`, `SESSION_SECRET`, `CLIENT_ORIGIN`, `GOOGLE_AI_API_KEY`, and `GEMMA_MODEL` as encrypted app secrets.
- Set server run command to `npm run start -w server`.
- Configure the client API base URL with `VITE_API_URL` at build time (e.g. `https://your-api-domain/api`).
- Apply migrations as a release/deploy step: `npm run db:deploy -w server`.
- Configure persistent object storage before enabling production user uploads.

### Cloudways
Cloudways is primarily PHP-oriented; confirm Node.js application support on the selected server/platform before deployment. If supported, deploy the Express service with its Node runtime/process manager, use managed PostgreSQL, configure HTTPS/reverse proxy and server-side environment variables. Otherwise host the Node API on DigitalOcean and use Cloudways only for a compatible frontend/static hosting arrangement.

## Production hardening still required
This starter does not claim production certification. Before public launch, add and verify:
- Real authentication (OIDC or secure password flow), per-user authorization and session lifecycle
- CSRF protection if cookie sessions are used; strict CORS and HTTPS
- Persistent user-scoped file storage (S3-compatible), malware scanning and OCR pipeline
- Automated tests, rate limiting backed by a shared store, monitoring and backups
- Full content review, accessibility audit and deployment verification

## Honest integration status
- Implemented: core navigation, searchable sample content, concept graph data, quiz sample workflow, sorting visualization, tool guide, basic API and database schema.
- Configurable: Gemma API (requires a valid key and a successful live request).
- Planned: production authentication, complete OCR/handwriting analysis, ChromaDB retrieval, Whisper voice, Ollama local inference and actual Graphify codebase graph.
