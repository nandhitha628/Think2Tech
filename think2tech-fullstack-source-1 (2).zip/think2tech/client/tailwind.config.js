/** @type {import('tailwindcss').Config} */
export default { content:["./index.html","./src/**/*.{ts,tsx}"], theme:{extend:{colors:{navy:"#101d36", aqua:"#eaf8f7", teal:"#16a6a0", ink:"#17243b"},fontFamily:{sans:["DM Sans","sans-serif"],display:["Manrope","sans-serif"]},boxShadow:{soft:"0 12px 36px rgba(25,55,75,.08)"}}},plugins:[] };
