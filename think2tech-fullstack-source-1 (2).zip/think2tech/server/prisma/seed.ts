import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const subjects = [
 ["dsa","Data Structures & Algorithms","Organize data and design efficient solutions."],
 ["c","C Programming","Understand memory, pointers and structured programming."],
 ["python","Python Programming","Build problem-solving skills with Python."],
 ["java","Java Programming","Learn object-oriented programming and the JVM."],
 ["os","Operating Systems","Explore processes, memory and concurrency."],
 ["dbms","Database Management Systems","Model, query and manage structured data."],
 ["dm","Discrete Mathematics","Build the mathematical foundations of computing."],
 ["aiml","AI & Machine Learning","Understand models, data and intelligent systems."],
 ["cn","Computer Networks","Understand communication between computers."]
] as const;
const concepts = [
 ["binary-search","Binary Search","dsa","Searching","Search Algorithms","Beginner","Find a target in sorted data by repeatedly halving the search range.","Binary search is an efficient search algorithm for sorted collections.","Compare the target with the middle value. Continue in the left or right half based on ordering.","In [2,4,7,9,12], searching for 9 checks 7, then 9.","Database indexes and lookup systems.",["search","sorted array"],["linear-search","sorting"]],
 ["linear-search","Linear Search","dsa","Searching","Search Algorithms","Beginner","Check each element in sequence until the target is found.","Linear search scans each element until it finds the target or reaches the end.","Start at index zero, compare each value, and stop on a match.","Find 8 in [3,8,2] by checking 3 then 8.","Small or unsorted collections.",["sequential search"],["binary-search"]],
 ["pointers","Pointers","c","Memory","Pointers and Addresses","Intermediate","A pointer stores the memory address of another object.","A pointer is a variable whose value is an address.","Use & to get an address and * to dereference a pointer.","int n=10; int *p=&n; then *p is 10.","Dynamic memory, arrays and linked lists.",["address","dereference"],["arrays-c"]],
 ["arrays-c","Arrays in C","c","Data Types","Arrays","Beginner","Store same-type elements in contiguous memory.","An array is a fixed-size sequence of elements of one type.","Access elements using zero-based indices.","int marks[3]={80,90,75};","Tables, buffers and collections.",["index","contiguous"],["pointers"]],
 ["python-list","Python Lists","python","Collections","Sequence Types","Beginner","An ordered, mutable collection.","A list is a built-in Python sequence created with square brackets.","Lists preserve order and can be changed with append, insert and remove.","scores=[80,90]; scores.append(95)","Records and data pipelines.",["append","mutable"],["python-dict"]],
 ["python-dict","Python Dictionaries","python","Collections","Mapping Types","Beginner","Store key-value pairs for lookup by key.","A dictionary maps unique hashable keys to values.","Create with braces and retrieve with a key or get().","student={'name':'Asha'}","Configuration and lookup tables.",["key value","mapping"],["python-list"]],
 ["java-oop","Object-Oriented Programming","java","OOP Fundamentals","Classes and Objects","Beginner","Model software using objects that combine state and behaviour.","OOP organizes programs around objects created from classes.","A class defines fields and methods; an object is an instance.","A Student class can contain name and calculateGrade().","Large applications and reusable design.",["class","object"],["java-inheritance"]],
 ["process","Process States","os","Process Management","Process Lifecycle","Beginner","A process moves through states as it is scheduled and completed.","A process is a program in execution with resources and execution context.","Common states: new, ready, running, waiting and terminated.","A process waiting for disk input is blocked.","Scheduling and resource management.",["ready","blocked"],["cpu-scheduling"]],
 ["normalization","Database Normalization","dbms","Relational Design","Normalization","Intermediate","Organize tables to reduce redundancy and update anomalies.","Normalization decomposes relations using dependencies.","1NF removes repeating groups; 2NF partial dependencies; 3NF transitive dependencies.","Move department details into a Department table.","Reliable relational database design.",["1NF","2NF","3NF"],["sql"]],
 ["sets","Sets and Set Operations","dm","Set Theory","Operations","Beginner","A set is a collection of distinct objects.","A set is an unordered collection of distinct elements.","Union combines; intersection finds common elements; difference subtracts.","A={1,2}, B={2,3}; A∪B={1,2,3}.","Databases, logic and probability.",["union","intersection"],["relations"]],
 ["neural-network","Neural Networks","aiml","Deep Learning","Neural Network Basics","Intermediate","Layers of connected units transform inputs into predictions.","A neural network is a parameterized function made of computational units.","Inputs pass through weighted sums and activations; training adjusts weights to reduce loss.","A classifier maps image features to class probabilities.","Image recognition and language tasks.",["weights","activation"],["classification"]],
 ["osi","OSI Model","cn","Network Models","Layered Architecture","Beginner","A seven-layer reference model for network communication.","OSI divides communication into seven functional layers.","Each layer provides services to the layer above and uses the layer below.","Routers mainly operate at the network layer.","Troubleshooting and network design.",["seven layers","encapsulation"],["tcp-ip"]]
] as const;
async function main(){
 for(const [id,name,description] of subjects) await db.subject.upsert({where:{id},update:{name,description},create:{id,name,description}});
 for(const [id,title,subjectId,chapter,topic,difficulty,summary,definition,explanation,example,application,keywords,relatedIds] of concepts)
  await db.concept.upsert({where:{id},update:{title,summary,definition,explanation},create:{id,title,subjectId,chapter,topic,difficulty,summary,definition,explanation,example,application,keywords:[...keywords],relatedIds:[...relatedIds]}});
 console.log(`Seeded ${subjects.length} subjects and ${concepts.length} starter concepts.`);
}
main().finally(()=>db.$disconnect());
