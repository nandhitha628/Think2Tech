import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { z } from "zod";
import { PrismaClient } from "@prisma/client";

const app=express(); const db=new PrismaClient(); const port=Number(process.env.PORT||4000);
app.use(helmet());
app.use(cors({origin:process.env.CLIENT_ORIGIN||"http://localhost:5173"}));
app.use(express.json({limit:"100kb"}));
app.use("/api/ai",rateLimit({windowMs:60_000,limit:20,standardHeaders:true,legacyHeaders:false}));
app.get("/api/health",(_req,res)=>res.json({ok:true,service:"think2tech-api"}));
app.get("/api/subjects",async(_req,res,next)=>{try{res.json(await db.subject.findMany({include:{_count:{select:{concepts:true}}}}));}catch(e){next(e)}});
app.get("/api/concepts",async(req,res,next)=>{try{const q=String(req.query.q||"").slice(0,100);const subjectId=String(req.query.subjectId||"");const where:any={};if(subjectId)where.subjectId=subjectId;if(q)where.OR=[{title:{contains:q,mode:"insensitive"}},{summary:{contains:q,mode:"insensitive"}},{chapter:{contains:q,mode:"insensitive"}},{topic:{contains:q,mode:"insensitive"}},{keywords:{has:q}}];res.json(await db.concept.findMany({where,include:{subject:true},take:100}));}catch(e){next(e)}});
app.get("/api/ai/status",(_req,res)=>res.json({configured:Boolean(process.env.GOOGLE_AI_API_KEY),tested:false,model:process.env.GEMMA_MODEL||"gemma-3-12b-it",provider:"Google Generative Language API",features:["SillySense explanations","Smart Quiz generation","Misconception feedback","NotesLens analysis","AI Learning Assistant"],message:process.env.GOOGLE_AI_API_KEY?"Key exists on server; live request not yet verified in this process.":"Add GOOGLE_AI_API_KEY to server environment."}));
const chatSchema=z.object({prompt:z.string().trim().min(2).max(5000)});
let gemmaTested=false;
app.post("/api/ai/chat",async(req,res,next)=>{try{
 const {prompt}=chatSchema.parse(req.body);
 if(!process.env.GOOGLE_AI_API_KEY){return res.json({source:"Demo fallback — Gemma not configured",text:`I can help you study "${prompt}". The live Gemma service is not configured yet. Add GOOGLE_AI_API_KEY on the server to enable real model responses. Meanwhile, try breaking the topic into its definition, working steps, example and common mistakes.`});}
 const model=process.env.GEMMA_MODEL||"gemma-3-12b-it";
 const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GOOGLE_AI_API_KEY)}`;
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),25000);
 try{
  const response=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:`You are THINK2TECH, a careful CSE tutor. Explain accurately and simply. If unsure, say so. Student question: ${prompt}`}]}],generationConfig:{temperature:0.4,maxOutputTokens:900}}),signal:controller.signal});
  const data:any=await response.json();if(!response.ok)throw new Error(data?.error?.message||"Gemma request failed");
  const text=data?.candidates?.[0]?.content?.parts?.map((p:any)=>p.text||"").join("\\n").trim();if(!text)throw new Error("Gemma returned no text");
  gemmaTested=true;res.json({source:`Gemma API · ${model}`,text});
 }finally{clearTimeout(timeout)}
 }catch(e:any){if(e instanceof z.ZodError)return res.status(400).json({error:"Invalid prompt",details:e.issues});res.status(502).json({error:"AI service failed",message:"The AI request could not be completed. Check server configuration and provider availability."});}
});
app.get("/api/ai/status/live",(_req,res)=>res.json({configured:Boolean(process.env.GOOGLE_AI_API_KEY),tested:gemmaTested,model:process.env.GEMMA_MODEL||"gemma-3-12b-it"}));
const uploadDir=path.resolve("uploads");fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({dest:uploadDir,limits:{fileSize:Number(process.env.MAX_UPLOAD_MB||10)*1024*1024},fileFilter:(_req,file,cb)=>{const allowed=["application/pdf","image/png","image/jpeg","text/plain"];cb(allowed.includes(file.mimetype)?null:new Error("Unsupported file type"),allowed.includes(file.mimetype));}});
app.post("/api/notes/upload",upload.single("file"),(req,res)=>{if(!req.file)return res.status(400).json({error:"Choose a PDF, PNG, JPG or TXT file."});res.status(201).json({id:req.file.filename,filename:req.file.originalname,size:req.file.size,status:"uploaded",analysis:"not_configured",message:"File validated and stored temporarily. OCR and AI analysis are not enabled in this starter."});});
app.use((err:any,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{console.error("Request error:",err?.message||"unknown");if(err?.code==="LIMIT_FILE_SIZE")return res.status(413).json({error:"File exceeds upload limit"});res.status(500).json({error:"Request failed. Please try again."});});
app.listen(port,()=>console.log(`THINK2TECH API listening on ${port}`));
